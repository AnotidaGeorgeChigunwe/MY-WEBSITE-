*********************************************************
*	       VisualEstablishment TTF v 0.9		*
*		  Created on June 2010 by 		*
*	      Alberto Alberti and Luca Zamoc		*
* 		 at Soolid comunicazione		*	
*							*
*      Copyright © Soolid comunicazione 201o, Italy	*
*     http://blog.soolid.it/ - http://www.soolid.it	*
*							*
*********************************************************

Thanks for download VisualEstablishment v0.9 (08/06/2010)
As you'll notice VisualEstablishment not a complete font set but a 
work in progress that requires many adjustments and bug fixes.

Feel free to use it for non-commercial purposes only.

If you want you can send us feedback or work including 
VisualEstablishment at info(at)soolid(dot)it

For commercial use contact us for licensing at info@soolid.it

If you want to donwload updated version or FontLabSource file
check http://blog.soolid.it

VisualEstablishment is distributed under CreativeCommons license
http://creativecommons.org/licenses/by-nc-nd/3.0/
